import os
from supabase import create_client, Client
from dotenv import load_dotenv

load_dotenv()

SUPABASE_URL = os.getenv("NEXT_PUBLIC_SUPABASE_URL")
SUPABASE_KEY = os.getenv("NEXT_PUBLIC_SUPABASE_ANON_KEY")

if not SUPABASE_URL or not SUPABASE_KEY:
    raise ValueError("Supabase URL or API Key is missing in your .env file.")

supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)


def get_user_by_username(username: str) -> dict | None:
    """
    Fetch a user by username.
    Returns a dict with user fields if found, else None.
    """
    try:
        response = supabase.table("users").select("username, password").eq("username", username).single().execute()
        return response.data
    except Exception as e:
        # Could be a not found or an actual error
        if "No row found" in str(e):
            return None
        print(f"⚠️ Error fetching user: {e}")
        return None


def insert_new_user(username: str, hashed_password: str) -> dict:
    """
    Insert a new user.
    Returns a dict with success or error message.
    """
    try:
        response = supabase.table("users").insert({"username": username, "password": hashed_password}).execute()

        if response.data:
            return {"message": "User inserted"}
        elif response.error:
            # Look for duplicate username
            if "duplicate" in str(response.error).lower():
                return {"error": "Username already exists"}
            return {"error": str(response.error)}

        return {"error": "Unknown insert failure"}

    except Exception as e:
        print(f"❌ Exception inserting user: {e}")
        return {"error": "Internal Server Error"}
